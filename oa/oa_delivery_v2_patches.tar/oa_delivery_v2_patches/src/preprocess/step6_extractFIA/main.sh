#x="hello"
source env.sh
source nest.sh
